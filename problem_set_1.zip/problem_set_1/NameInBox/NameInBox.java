public class NameInBox
{
   public static void main(String[] args)
   {

   }
}
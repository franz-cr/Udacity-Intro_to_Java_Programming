//hw01_07
public class LengthPrinter
{
    public static void main(String[] args)
    {
        String course = "Udacity"; //do not modify this line in any way

        //complete the code to find the length of the string
        //your code here

    }
}

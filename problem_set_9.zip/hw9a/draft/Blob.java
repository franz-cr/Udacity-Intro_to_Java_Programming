//HIDE
// Ignore this class. It is just here so I can test if you implemented the interface correctly
public class Blob implements GeometricSolid
{
   public double getVolume()
   {
       return 0;
   }

   public double getSurfaceArea()
   {
       return 0;
   }
}

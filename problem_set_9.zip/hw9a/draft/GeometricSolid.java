// This problem has several parts.
// First complete the GeometricSolid interface. The interface has two methods
//      getVolume and getSurfaceArea
//both of which return a double
//
// Then modify the both the Shere and the Cube method to implement the
// GeometricSolid interface
//
// For the draft, complete the GeometricSolid interface
public interface GeometricSolid
{

}

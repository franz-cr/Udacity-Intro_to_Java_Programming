import java.util.Scanner;

public class MileagePrinter
{
   public static void main(String[] args)
   {

   }
}

//hw03-10
/**
 * Compelete the method to return the average of three numbers
 */
public class AverageTest
{
  public double average(int test1, int test2, int test3)
  {
      //you can put code here
      return  //...your code coes here
  }
}

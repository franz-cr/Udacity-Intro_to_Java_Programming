public class YardCalculator
{
   ///your code here
}
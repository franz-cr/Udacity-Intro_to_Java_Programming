public class YardCalculatorTester
{
    public static void main(String[] args)
    {
        final double LENGTH = 60.1;
        final double WIDTH = 35.5;
        
       YardCalculator calculator = new YardCalculator(LENGTH, WIDTH);
       
       System.out.println("No output");
       System.out.println("Expected: No output");
        
    }
}
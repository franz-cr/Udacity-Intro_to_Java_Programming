//hw03_08
/*
 * Complete the code to find the volume of a cone with radius r and height h
 */
public class Cone
{
   /**
    * Gets the volume of a cone
    * @param r the radius of the cone
    * @param h the height of the cone
    */
   public double volume(int r, int h)
   {
       double volume;
       //your code is here
       return volume;
   }
}
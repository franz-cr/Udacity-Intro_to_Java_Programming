
/**
 * Tests the Balloon class
 * 
 * @author KOBrien
 */
public class BalloonTester
{
   public static void main(String[] args)
   {
       Balloon balloon = new Balloon();
       System.out.println(balloon.getVolume());
       System.out.println("Expected: 0.0");
       
   }
}

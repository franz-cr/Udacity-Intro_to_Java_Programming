
/**
 * models a spherical balloon that is being filled with air
 *
 * @author KOBrien
 */
public class Balloon
{


    /**
     * Constructor for objects of class Balloon
     */
    public Balloon()
    {

    }

    /**
     * Gets the volume of the Balloon
     *
     * @return    the volume of this balloon
     */
    public double getVolume()
    {
        return volume;
    }
}

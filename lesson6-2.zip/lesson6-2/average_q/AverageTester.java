
public class AverageTester
{
    public static void main(String[] args)
    {
        Average averager = new Average();
        System.out.println(averager.average());
    }
}

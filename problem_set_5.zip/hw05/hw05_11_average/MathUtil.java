//hw05_11
//
// Complete this method to read integer scores from the user and find the average
 // Stop asking for input when the user enters zero or  a negative number
// keep a running total and keep track of the number of entries
// then find and return the average
// Be sure not to divide by 0. Return 0 if no scores are entered
//

import java.util.Scanner;
public class MathUtil
{
    public double averageScore()
    {
        //TODO Find and return the average of the numbers entered.
        System.out.print("Enter a score. 0 to quit: "); //use this for the prompt

    }
}

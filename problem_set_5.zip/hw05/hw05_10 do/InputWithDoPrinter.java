
public class InputWithDoPrinter
{
   public static void main(String[] args)
   {
       InputWithDo input = new InputWithDo();
       input.getValidInput();
   }
}

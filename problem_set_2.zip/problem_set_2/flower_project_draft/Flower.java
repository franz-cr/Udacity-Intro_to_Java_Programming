public class Flower
{
  //your code here

   public Flower(int theX, int theY)
   {
         //your code here
   }

   public void draw()
   {
         //your code here
   }
}

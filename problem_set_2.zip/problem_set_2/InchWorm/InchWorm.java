public class InchWorm
{
   //your code goes here

}

public class InchWormTesterDraft
{
   public static void main(String[] args)
   {
       InchWorm worm1 = new InchWorm();
       
   }
}

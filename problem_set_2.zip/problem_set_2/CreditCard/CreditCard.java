/**
   A credit card has a balance that can be changed by
   purchases and payments.
*/
public class CreditCard
{

}

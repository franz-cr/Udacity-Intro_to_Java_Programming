
public class CreditCardTesterDraft
{
   public static void main(String[] args)
   {
       CreditCard visa = new CreditCard();
   }
}

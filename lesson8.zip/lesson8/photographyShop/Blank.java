public class Blank
{

}

import java.awt.Point;

public class PolygonTest
{
 
    public static void main(String[] args)
    {
       
       Polygon shape = new Polygon();
       System.out.println(shape.perimeter());
       System.out.println("Expected: 0");
       
    }
}

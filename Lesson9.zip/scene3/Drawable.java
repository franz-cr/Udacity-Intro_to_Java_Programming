//HIDE
public interface Drawable
{
    void draw();
}

//HIDE
public interface Moveable
{
    void move(int seconds);
}
